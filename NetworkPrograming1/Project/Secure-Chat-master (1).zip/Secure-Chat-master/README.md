# secure-chat
This software uses a TCP secure connection and send messages with various Encryption/Decryption Algorithms Including DES3 and RSA , <br> This Project includes from two part the server and client for chatting , server listens on a specific port, you may find persian (Fingilish فارسی) description in files , any contribute for documention is helpful.

This System Codes in VS 2010 Utimate
