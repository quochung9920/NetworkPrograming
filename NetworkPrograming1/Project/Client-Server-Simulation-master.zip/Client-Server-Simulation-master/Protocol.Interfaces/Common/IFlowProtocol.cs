﻿namespace FlowProtocol.Interfaces.Common
{
    public interface IFlowProtocol { }
}