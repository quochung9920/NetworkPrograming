﻿namespace FlowProtocol.Interfaces.Servers
{
    public interface IServer
    {
        void StartListeningToPort(int port);
    }
}