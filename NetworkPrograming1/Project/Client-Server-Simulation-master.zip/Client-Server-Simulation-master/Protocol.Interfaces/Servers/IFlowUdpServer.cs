﻿namespace FlowProtocol.Interfaces.Servers
{
    public interface IFlowUdpServer : IServer { }
}