﻿namespace FlowProtocol.Interfaces.Servers
{
    public interface IFlowTcpServer : IServer { }
}