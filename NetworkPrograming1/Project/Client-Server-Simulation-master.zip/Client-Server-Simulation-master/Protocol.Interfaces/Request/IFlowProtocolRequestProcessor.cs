﻿namespace FlowProtocol.Interfaces.Request
{
    public interface IFlowProtocolRequestProcessor
    {
        string ProcessRequest(string request);
    }
}