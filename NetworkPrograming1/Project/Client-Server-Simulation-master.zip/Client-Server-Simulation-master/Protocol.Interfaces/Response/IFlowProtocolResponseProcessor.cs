﻿namespace FlowProtocol.Interfaces.Response
{
    public interface IFlowProtocolResponseProcessor
    {
        string ProcessResponse(string response);
    }
}