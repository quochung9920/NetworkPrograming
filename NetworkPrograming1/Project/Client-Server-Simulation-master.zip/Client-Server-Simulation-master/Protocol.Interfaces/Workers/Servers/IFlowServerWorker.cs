﻿namespace FlowProtocol.Interfaces.Workers.Servers
{
    using Common;

    /* TCP/UDP Server */
    public interface IFlowServerWorker : IFlowProtocol { }
}