﻿namespace FlowProtocol.Interfaces.Workers.Clients
{
    public interface IFlowTcpClientWorker : IFlowClientWorker { }
}