﻿namespace FlowProtocol.Interfaces.Workers.Clients
{
    public interface IFlowUdpClientWorker : IFlowClientWorker { }
}