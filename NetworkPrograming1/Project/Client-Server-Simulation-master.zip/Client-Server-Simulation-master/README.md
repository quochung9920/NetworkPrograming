# Client-Server Flow Chat App



![Chat Client](https://image.prntscr.com/image/fIdKhI--RTCXSr4k2h4sLQ.png)



![Chat Server](https://image.prntscr.com/image/51ixS1m9SQK0RP1qYRsq-Q.png)
