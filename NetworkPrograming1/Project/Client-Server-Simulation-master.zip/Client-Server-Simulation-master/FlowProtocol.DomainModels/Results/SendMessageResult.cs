﻿namespace FlowProtocol.DomainModels.Results
{
    public class SendMessageResult
    {
        public bool Success { get; set; }
        public string ResponseMessage { get; set; }
    }
}