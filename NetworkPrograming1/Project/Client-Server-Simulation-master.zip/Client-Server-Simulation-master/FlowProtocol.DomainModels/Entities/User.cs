﻿namespace FlowProtocol.DomainModels.Entities
{
    public class User
    {
        public string Name { get; set; }
        public string Pass { get; set; }
        public string Login { get; set; }
    }
}