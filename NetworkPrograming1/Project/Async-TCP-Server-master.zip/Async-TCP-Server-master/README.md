# Async-TCP-Server
Simple Asynchronous TCP Server for testing asynchronous communication.
Compatible with TCP Client.
