# Simple C# chat
A simple C# chat using WinForms and TCP sockets.

Project done for our school, EFREI.
