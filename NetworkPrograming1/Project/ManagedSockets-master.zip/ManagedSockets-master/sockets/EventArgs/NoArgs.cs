﻿namespace Sockets.EventArgs {
    public delegate void NoEventArgs();
}